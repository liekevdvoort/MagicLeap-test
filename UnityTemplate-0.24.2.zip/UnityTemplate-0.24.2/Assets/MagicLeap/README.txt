// %BANNER_BEGIN%
// ---------------------------------------------------------------------
// %COPYRIGHT_BEGIN%
//
// Copyright (c) 2019 Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://id.magicleap.com/terms/developer
//
// %COPYRIGHT_END%
// ---------------------------------------------------------------------
// %BANNER_END%

The files in this folder are meant to provide examples, best practices and wrappers to
help the user work and understand the MagicLeap APIs.

These files can change or even be removed from one release to another. If you're planning
on depending or modifying these assets for your own project, we recommend that you duplicate
the files, change the names and move them out of the Assets/MagicLeap folder. This will avoid
issues like your changes being deleted when you upgrade to a new unitypackage.